-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: vcs
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `channel` varchar(20) DEFAULT NULL,
  `password` varchar(20) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `mobile` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `imgpath` varchar(255) NOT NULL DEFAULT 'users/images/default.jpeg',
  `role_id` int DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Dr.Ali','SELJ7C','123456','2020-12-21 17:22:12',NULL,NULL,'images/profileImgs/index.jpg',4),(3,'Dr.Mostafa','F6PUQV','MoMo123456789@','2021-01-10 15:07:06',NULL,NULL,'users/images/default.jpeg',1),(4,'ADSCCVCS','9SVENM','Vcs1234@','2021-02-17 22:03:03',NULL,NULL,'users/images/default.jpeg',1),(11,'YASKCVCS',NULL,'Yas@pqw1234','0000-00-00 00:00:00',NULL,NULL,'users/images/default.jpeg',3),(12,'osama','9RFSIB','123456','2021-10-26 01:45:43','123456','osamaalaa@mail.com','users/images/osama_334905Health-care.jpg',2),(14,'Dr.Rafik Karam',NULL,'Yas@2022','2021-10-26 02:06:49',NULL,NULL,'users/images/default.jpeg',1),(39,'yazen','ca4c29','123456','2022-01-26 12:11:56','0522200730','yazen@mail.com','users/images/default.jpeg',1),(40,'patient01','9RFSITT','123456','2021-10-26 01:45:43','123456','osamaalaa@mail.com','users/images/osama_334905Health-care.jpg',2),(43,'Recipionist','02400a','123456','2022-02-07 14:23:40','123456','osamaalaa133@gmail.com','users/images/default.jpeg',6);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-27 19:23:06
