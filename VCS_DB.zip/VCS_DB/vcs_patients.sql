-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: vcs
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pid` varchar(25) NOT NULL,
  `pname` varchar(100) DEFAULT NULL,
  `cheifcomplaint` varchar(100) DEFAULT NULL,
  `mri` varchar(45) DEFAULT NULL,
  `sickleave` varchar(45) DEFAULT NULL,
  `wfh` varchar(45) DEFAULT NULL,
  `doctor_name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `DELETED` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (1,'0','','','',NULL,'',NULL,'2022-01-03 12:46:50',0),(2,'0','','','',NULL,'',NULL,'2022-01-03 12:50:24',0),(3,'0','','','',NULL,'',NULL,'2022-01-03 13:01:43',0),(4,'0','','','',NULL,'',NULL,'2022-01-03 13:04:55',0),(5,'0','','','',NULL,'',NULL,'2022-01-03 13:05:25',0),(6,'0','test','ests','test',NULL,'',NULL,'2022-01-03 13:07:51',0),(7,'0','test','setset','tset',NULL,' .  . ',NULL,'2022-01-03 13:10:01',0),(8,'0','test','setset','test',NULL,'on',NULL,'2022-01-03 13:12:27',0),(9,'0','test','setset','est','','',NULL,'2022-01-03 13:14:27',0),(10,'0','test','set','set','on',NULL,NULL,'2022-01-03 13:18:28',0),(11,'0','osamaaa','osamasdasd','osama','on',NULL,NULL,'2022-01-03 16:36:35',0),(12,'0','asdasd','asdasd','asd','on',NULL,NULL,'2022-01-03 16:38:27',0),(13,'0','ma4e','ma4e','ma4e','on',NULL,NULL,'2022-01-03 16:41:36',0),(14,'0','sds','sdf','sdf','on',NULL,NULL,'2022-01-03 16:41:52',0),(15,'0','lalala','lalala','lalala','on','no',NULL,'2022-01-03 16:45:42',0),(16,'0','teeest','testt','testtt','no','yes',NULL,'2022-01-03 16:46:50',0),(17,'0','test','set','set','yes','no',NULL,'2022-01-03 16:51:41',0),(18,'0','test','settse','tse','no','yes',NULL,'2022-01-03 16:52:10',0),(19,'0','te4st','ste','ste','no','no',NULL,'2022-01-03 16:58:27',0),(20,'0','test','settsetes','testse','yes','no','osama','2022-01-03 17:08:20',0),(21,'0','test','settse','set','no','no','osama','2022-01-03 17:11:55',0),(22,'0','test','tse','set','no','no','12','2022-01-03 17:12:39',0),(23,'968946','test','stetse','set','no','no','12','2022-01-03 17:31:44',0),(24,'','test','setste','set','yes','no','12','2022-01-03 17:37:14',0),(25,'161378','test','sett','set','no','no','12','2022-01-03 17:45:37',0),(26,'712666','tes','set','set','yes','yes','12','2022-01-03 17:46:40',0),(27,'740390','ste','tse','ste','no','','12','2022-01-03 17:46:53',0),(28,'785854','ser','ser','ser','no','no','12','2022-01-03 17:50:55',0),(29,'870772','testset','setset','setset','yes','no','12','2022-01-03 17:53:59',0),(30,'820632','test','set','tset','yes','yes','osama','2022-01-05 10:49:11',0),(31,'668914','test','set','set','yes','yes','osama','2022-01-05 10:50:27',0),(32,'970336','test','tse','ste','yes','yes','osama','2022-01-05 10:57:03',0),(33,'494540','test','settse','test','yes','yes','osama','2022-01-05 10:59:54',0),(34,'246884','test','setset','tsetset','yes','yes','osama','2022-01-05 11:02:08',0),(35,'264797','test','set','set','yes','yes','osama','2022-01-05 11:03:03',0),(36,'971000','testtt','setset','setset','yes','yes','osama','2022-01-05 11:04:11',0),(37,'137048','test','set','set','yes','yes','osama','2022-01-05 11:20:08',0),(38,'846018','test','set','testtt','yes','yes','osama','2022-01-05 11:22:59',0),(39,'955896','test','setet','testtt','yes','yes','osama','2022-01-05 11:23:31',0),(40,'479914','test','setset','etst','yes','yes','osama','2022-01-05 11:23:57',0),(41,'143385','osama','osama','osama','yes','yes','osama','2022-01-05 11:24:08',0);
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-27 19:23:06
