-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: vcs
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointments` (
  `appointments_id` int NOT NULL AUTO_INCREMENT,
  `uuid` varchar(45) NOT NULL,
  `patient_name` varchar(255) DEFAULT NULL,
  `doctor_name` varchar(255) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `time` varchar(25) DEFAULT NULL,
  `status` int NOT NULL DEFAULT '1' COMMENT '1=Active, 0=Block',
  `phone_number` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` int DEFAULT '0',
  PRIMARY KEY (`appointments_id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointments`
--

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
INSERT INTO `appointments` VALUES (27,'123456','test','Dr.Ali','testt','Tue Feb 01 2022 14:42:37 GMT+0400 (Gulf Standard Time)','22:11',3,'0522200730','2022-02-01 10:42:50',0),(28,'12346','appointment1','Dr.Ali','TestAppointmentTeam','Tue Feb 01 2022 14:54:46 GMT+0400 (Gulf Standard Time)','11:00',3,'0522200730','2022-02-01 10:55:09',0),(30,'784112345','Osama','Dr.Ali','Osama Note','Wed Feb 02 2022 12:20:51 GMT+0400 (Gulf Standard Time)','11:00',3,'0522200730','2022-02-02 08:21:12',0),(31,'123456','osama','Dr.Ali','test','Sat Feb 05 2022 16:18:42 GMT+0400 (Gulf Standard Time)','22:01',3,'123456','2022-02-05 12:18:56',0),(32,'123456','rest','Dr.Ali','test','Sat Feb 05 2022 16:25:42 GMT+0400 (Gulf Standard Time)','22:11',3,'0522200730','2022-02-05 12:25:58',0),(33,'123456','OsamaaAlaa','Dr.Ali','Test','Tue Feb 15 2022 13:51:03 GMT+0400 (Gulf Standard Time)','22:11',2,'123456789','2022-02-15 09:51:20',0),(34,'test','test','Dr.Ali','test','Wed Feb 02 2022 00:00:00 GMT+0400 (Gulf Standard Time)','10:11',2,'123456','2022-02-15 09:51:57',0),(35,'test','test','Dr.Ali','testtt','Wed Feb 02 2022 00:00:00 GMT+0400 (Gulf Standard Time)','22:11',1,'123456','2022-02-15 09:52:56',0),(36,'test','test','Dr.Ali','test','2022-01-31','10:11',1,'123456','2022-02-15 09:54:59',0),(37,'test','test','Dr.Ali','testt','2022-02-23','22:11',1,'123465','2022-02-15 09:56:24',0),(38,'test','testDev','Dr.Ali','test','2022-02-14','10:11',1,'123456','2022-02-15 10:00:54',0),(39,'test','test','Dr.Ali','etestset','2022-02-15','10:11',1,'test','2022-02-15 11:19:26',0),(40,'Jasim','Jasim','Dr.Ali','testt','2022-02-16','10:11',1,'123456','2022-02-15 11:20:11',0),(41,'test','test','Dr.Ali','ttestt','Thu Feb 17 2022 00:00:00 GMT+0400 (Gulf Standard Time)','10:11',1,'test','2022-02-15 11:22:38',0),(42,'Osamaa','Osamaaa','Dr.Ali','testtt','2022-02-17','10:11',1,'123456','2022-02-15 11:23:12',0),(43,'123456','Osamaaaaaaa','Dr.Ali','test','2022-02-09','10:11',3,'1231564','2022-02-15 11:24:36',0),(44,'test','test','Dr.Ali','testtt','','10:11',1,'123456','2022-02-15 11:35:34',0),(45,'478954','Vimala','Dr.Ali','Test Vimala','2022-02-25','22:11',3,'0522200730','2022-02-17 07:00:40',0);
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-27 19:23:06
